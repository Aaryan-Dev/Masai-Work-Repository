import React from "react";
import Filter from "../Components/Filter";

const Shoes = () => {
  return (
    <div>
      <Filter />
      <div>
        {/* Map through the shoes list here using ShoeCard Component */}
      </div>
    </div>
  );
};

export default Shoes;
